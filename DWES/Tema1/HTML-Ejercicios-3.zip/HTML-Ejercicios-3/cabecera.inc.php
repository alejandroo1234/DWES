<?php
    echo '<header> <h1> Alejandro</h1> <p> Me gusta el futbol y el bicho </p> </header>';
?>
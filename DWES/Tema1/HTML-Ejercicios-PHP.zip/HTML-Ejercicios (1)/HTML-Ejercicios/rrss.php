<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="RRSS" content="width=device-width, initial-scale=1.0">
    <title>rrss</title>
</head>

<body>
    <?php
        include("cabecera.inc.php");
    ?>
    <nav>
        <img src="x.jpeg" alt="Twitter" width="5%" height="5%">
        <a href="https://twitter.com/?lang=es">Ir a twitter</a>
        <br>
        <img src="facebook.png" alt="facebook" width="5%" height="5%">
        <a href="https://www.facebook.com/?locale=es_ES">Ir facebook</a>
        <br>
    </nav>

    <footer>
        <a href="principal.php">Ir al principal</a>
    </footer>


</body>

</html>
<?php
    interface Resumible{
        public function getMuestraResumen();
    }
?>